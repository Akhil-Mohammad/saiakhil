package progransss;

public class ReverseWords {

	public static void main(String[] args) {
		String temp="";
		String str="Hello World";
		String[] d= str.split(" ");
		for(int i=d.length-1;i>=0;i--) {
			temp= temp+ d[i]+" ";
			//temp= temp+ch+" ";

		}
		System.out.println(temp);	
	}
	
}
