package progransss;

public class ReverseString {

	public static void main(String[] args) {
		
		String str="hello";
		String temp="";
		for(int i=str.length()-1;i>=0;i--) {
			char ch=str.charAt(i);
			temp=temp+ch;
		}
		System.out.println(temp);
	}
}
