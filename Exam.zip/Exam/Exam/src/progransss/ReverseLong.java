package progransss;

public class ReverseLong {

	public static void main(String[] args) {
		
		long l=12345678;
		long rev,sum=0;
		while(l>0) {
			rev=l%10;
			sum= (sum*10)+rev;
			l=l/10;
			System.out.print(rev);
			
		}
	}
}
