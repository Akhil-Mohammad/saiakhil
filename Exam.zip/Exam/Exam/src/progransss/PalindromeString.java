package progransss;

public class PalindromeString {

	public static void main(String[] args) {
		
	
	String str="akhka";
	String temp="";
	//String h=str;
	for(int i=str.length()-1;i>=0;i--) {

		char ch=str.charAt(i);
		temp=temp+ch;
		
	}
	System.out.println(temp);
	if(str.equals(temp)) {
		System.out.println("String Palindrome");
	}else {
		System.out.println("Not String Palindrome");
	}
}
}