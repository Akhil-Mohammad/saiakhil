package progransss;

public class ReverseArray {
public static void main(String[] args) {
	int i;

	int[] it= {1,2,3,4,5};
	
	for( i= it.length-1;i>=0;i--) {

		System.out.print(it[i]);		
	}

}
}