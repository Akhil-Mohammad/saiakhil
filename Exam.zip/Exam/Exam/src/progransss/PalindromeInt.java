package progransss;

public class PalindromeInt {
public static void main(String[] args) {
	

	int num=121,sum=0;
	int temp=num;
	while(num>0) {
		int rev=num%10;
		 sum= (sum*10) +rev;
		 num=num/10;
		
	}
	if(sum==temp) {
		System.out.println("palindrome String");
	}else {
		System.out.println("Not Palindrome string");
	}
}
}