package progransss;

public class StringSpaces {

	public static void main(String[] args) {
		
		String str="hello world";
		str=str.replace(" ","");
		System.out.println(str);
		
	}
}
 