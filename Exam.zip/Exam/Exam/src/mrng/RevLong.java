package mrng;

public class RevLong {

	public static void main(String[] args) {
		
		
		long num=1234587458;
		long rev, sum=0;
		
		while(num>0) {
			rev=num%10;
			sum=(sum*10)+rev;
			num=num/10;
			
			System.out.print(rev);
		}
		
	}
}
