package mrng;

public class PalindromString {
public static void main(String[] args) {
	

	String str="akhil";
	String temp=str;
   String rev="";
	for(int i=str.length();i>=0;i--) {
	char ch=str.charAt(i);
	rev = rev +ch;
	}
	if(temp==str) {
		System.out.println("yes");
	}else {
		System.out.println("no");
	}
}
}