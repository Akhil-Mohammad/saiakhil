package mrng;

public class Palinmdrome {
public static void main(String[] args) {
	

	int num=121,sum = 0;
	int temp=num;
	int rev = 0;
	while(num>0) {
		rev=num%10;
	sum=(sum*10)+rev;
	num=num/10;
	}

	if(sum==temp) {
		System.out.println("yes");
	}else {
		System.out.println("no");
	}
	}
	
	}
