package mrng;

public class Spaces {

	public static void main(String[] args) {
		String str="Hello World";
	String s=	str.replace(" " , "");
		System.out.println(s);
	}
}
