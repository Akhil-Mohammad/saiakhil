package mrng;



public class WordRev {

	public static void main(String[] args) {
		String str = "Hello WOrld";
		String temp="";
		String[] rev = str.split(" ");
		for (int i = rev.length - 1; i >=0; i--) {
			temp=temp+rev[i]+" ";
			
		}
		System.out.println(temp);
	}
}
