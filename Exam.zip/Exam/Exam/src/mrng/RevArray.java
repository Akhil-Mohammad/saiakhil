package mrng;

public class RevArray {
public static void main(String[] args) {
	

	int[] it= {1,2,3,4,5};
	for(int i =it.length-1;i>=0;i--) {

		System.out.print(it[i]);
	}
}
}