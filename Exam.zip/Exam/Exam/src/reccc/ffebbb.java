package reccc;

public class ffebbb {

	public static int ffebb(int num) {
		if(num==0||num==1) {
			return num;
		}
		else {
			return ffebb(num-1)+ffebb(num-2);
		}
	}
	public static void main(String[] args) {
		for(int i=0;i<=10;i++) {
		System.out.println(ffebb(i));
	}
}
}