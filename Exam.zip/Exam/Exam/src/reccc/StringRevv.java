package reccc;

import java.security.DomainCombiner;

public class StringRevv {

	public static String strRev(String str,int num,String rev) {
		if(num<0) {
			return rev;
		}
		else {
			rev= rev+str.charAt(num);
			return str.charAt(num)+strRev(str, num-1, rev);
		}

	}
	public static void main(String[] args) {
		String s="akhil mohammad";
		System.out.println(strRev(s, s.length()-1, " "));
	}
}
