package reccc;

public class RevLOng {

	public static void rev(long num) {
		if(num<10) {
			System.out.println(num); 
		}
		else {
			System.out.print(num%10);
			rev(num/10);
			
		}
		
	}
	public static void main(String[] args) {
		rev(10);
	}
}
