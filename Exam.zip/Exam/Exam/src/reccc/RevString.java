package reccc;

public class RevString {

	public static String rev(String str) {
		if(str.isEmpty()) {
			return str;
		}
		else {
			return rev(str.substring(1))+str.charAt(0);
			
		}
		
	}
	public static void main(String[] args) {
		
		String str="akhil";
		String y=str;
		String revStr = rev(y);
		
		System.out.println(revStr);
	}
}
