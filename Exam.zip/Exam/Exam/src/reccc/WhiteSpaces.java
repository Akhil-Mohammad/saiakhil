package reccc;

public class WhiteSpaces {

	public static String whitespace (String str) {
		if(str.length() == 0) {
			return "";
		}
		char ch=str.charAt(0);
		String rech = str.substring(1);
	
		if(Character.isWhitespace(ch)) {
			return whitespace(rech);
			
		}else {
			return ch +whitespace(rech);
		}
	
	}
	
	public static void main(String[] args) {
		String str= "Hello World";
		String trimm =whitespace(str);
		System.out.println(trimm);
				
	}
}
