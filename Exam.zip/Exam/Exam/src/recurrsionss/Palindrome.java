package recurrsionss;

public class Palindrome {

	public static boolean ispalin(int num) {
		int revv = reverse(num, 0);
		return num==revv;
	}
	
	public static int reverse(int num,int rev) {
		if(num==0) {
			return rev;
		}else {
			int digit = num%10;
			int newrev = rev*10+digit;
			int rem=num/10;
			return reverse(rem, newrev);
		}
		
	}
	
	public static void main(String[] args) {
		if(ispalin(121)) {
			System.out.println("palindrome");
		}else {
			System.out.println("Not plaindrome");
		}
	}
}
