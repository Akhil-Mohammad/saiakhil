package recurrsionss;

import java.util.Scanner;

public class Fabinacci {

	public static int fibanacci(int n) {
		if(n==0 || n==1) {
			return n;
		}else {
			return fibanacci(n-1)+fibanacci(n-2);
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the range");
		int n=sc.nextInt();
		System.out.println(n);
		for(int i=0;i<n;i++) {
			System.out.println(fibanacci(i));
		}
	sc.close();
	}
}
