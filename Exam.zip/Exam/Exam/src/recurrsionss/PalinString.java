package recurrsionss;

public class PalinString {

	public static boolean ispalin(String in) {
		if(in.length() ==0 || in.length() ==1){
		return true;
		}
		if(in.charAt(0)== in.charAt(in.length()-1)) {
			return ispalin(in.substring(1,in.length()-1));
		}else {
			return false;
		}
	}
	public static void main(String[] args) {
		if(ispalin("akhk")) {
			System.out.println("palindrome string");
		}else {
			System.out.println("Not Plaindrome");
		}
	}
}
